import Logo from '../images/logo.png'
import '../css/header.css'
import '../css/section.css'
import '../css/section2.css'
import Bc from '../images/bc.png'
import Gril from '../images/Gril.png'
import Stylish from '../images/sytlish.png'
import Cta from '../images/cta.png'
import Qorasomka from '../images/blackbag.png'
import Sumka from '../images/qorabag.png'
import kuli from '../images/zaryad.png'
import Pshti from '../images/pushtibag.png'
import Sumkalar from '../images/sumkalar.png'
import Ochqizil from '../images/ochqizil.png'
import Blue from '../images/blue.png'
import Blues from '../images/blues.png'
import Toqsiyoh from '../images/image.png'
import Ochyashil from '../images/ochyashil.png'
import Qizilsumka from '../images/qizil-sumka.png'
import Qizil from '../images/oddiyqizil.png'
import Qizilrang from '../images/ochqizil.png'
import Bola from '../images/gays.png'
import { FontAwesomeIcon } from "@fortawesome/react-fontawesome";
import { faArrowRight } from "@fortawesome/free-solid-svg-icons";


function header() {
    return (
        <div>
            <header >
                <div className='header-logo'>
                    <img src={Logo} alt="Logo" />
                </div>
                <div className='header-menu'>
                    <ul className="list">
                        <li className="item">
                            <a href="#" className="link">Home</a>
                        </li>
                        <li className="item">
                            <a href="section-2" className="link">Feature</a>
                        </li>
                        <li className="item">
                            <a href="#" className="link">About</a>
                        </li>
                        <li className="item">
                            <a href="#" className="link">Product</a>
                        </li>
                    </ul>
                    <div className='shopping-btn'>
                        <button className="btn">Shop now</button>
                    </div>
                </div>
            </header>
            <section id='section-1' className='section-1'>
                <div className='section-text'>
                    <p className='text-1'>
                        Look Stylish Be Stylish.
                    </p>
                    <p className='text-2'>Look Stylish <br /> Be <img src={Stylish} alt="" /></p>
                    <p className='text-3'>Before starting this business you should have ideas <br /> about the market and products to Compete with the <br /> Existing Businesses.</p>
                    <div className='section-btn'>
                        <button className="btn">Join Shop</button>
                        <img src={Cta} alt="" />
                    </div>
                </div>
                <div className="wrapper">
                    <img src={Bc} alt="background" className="background" />
                    <img src={Gril} alt="girl" className="girl" />
                </div>
            </section>
            <section className='section-2'>
                <div className='section-2-text1'>

                    <ul className="list">
                        <li className="item">
                            <a href="#" className="link">water resistant</a>
                        </li>
                        <li className="item">
                            <a href="#" className="link">charging system</a>
                        </li>
                        <li className="item">
                            <a href="#" className="link">artificial leather</a>
                        </li>
                        <li className="item">
                            <a href="#" className="link">modern clothes</a>
                        </li>
                    </ul>
                    <div className='section-2-chiziq'></div>
                    <div className="section-2-bag">
                        <div className="bag-img"><img src={kuli} alt="" /></div>
                        <div className="bag-img"><img src={Sumka} alt="" /></div>
                        <div className="bag-img"><img src={Qorasomka} alt="" /></div>
                        <div className="bag-img"><img src={Pshti} alt="" /></div>
                    </div>
                </div>
                <div className="section-2-content">
                    <div className="section-2-img"><img src={Sumkalar} alt="" /></div>
                    <div className='section-text'>
                        <p className='text-1'>
                            Creative bag only for you.
                        </p>
                        <p className='text-4'>Lorem ipsum dolor sit amet <br /> consectetur adipiscing elit <br /> sed do eiusmod.</p>
                        <p className='text-3'>Lorem ipsum dolor sit amet, consectetur adipiscing elit, <br /> sed do eiusmod tempor incididunt ut labore et dolore <br /> magna aliqua. Ut enim ad minim veniam.</p>
                        <button className="btn">See More</button>
                    </div>
                </div>
                <div className="section-2-Our">
                    <p className='our-1-text'>our available product</p>
                    <p className='our-2-text'>Lorem ipsum dolor sit amet, consectetur adipiscing elit, sed do <br /> eiusmod tempor incididunt ut labore et dolore.</p>
                    <div>
                        <img src={Ochqizil} alt="" />
                        <img src={Blue} alt="" />
                        <img src={Blues} alt="" />
                        <img src={Toqsiyoh} alt="" />
                        <img src={Ochyashil} alt="" />
                        <img src={Qizilsumka} alt="" />
                        <img src={Qizil} alt="" />
                        <img src={Qizilrang} alt="" />
                    </div>
                    <button className='btn'> See More <FontAwesomeIcon icon={faArrowRight} /></button>
                </div>
                <div className="login">
                    <div className="img">
                        <img src={Bola} alt="" />
                    </div>
                    <div className="login-text">
                        <p>
                            Lorem ipsum dolor sit amet <br />  adipiscing elit.
                        </p>
                        <div className="login-input">
                            <input type="text" placeholder='Name' />
                            <input type="text" placeholder='Email' />
                        </div>
                        <div className="inpu-btn">

                            <input className='inpr-1' type="text" placeholder='Password' />
                        </div>
                        <button className='btn btn1'>Join Now</button>
                    </div>
                </div>
            </section>
        </div>
    )
}

export default header