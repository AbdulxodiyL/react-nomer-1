import Header from './companients/header'
import './css/App.css'
import Home from './pages/Home'

function App() {

  return (
    <>
      <div className='background-img'>
        <div className='container'>
          <Header />

          <Home />
        </div>
      </div>
    </>
  )
}

export default App
